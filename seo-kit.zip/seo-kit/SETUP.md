# SEO-kit setup for millkinnisvara.ee

Three pieces here: `SEO.astro` (meta tags + structured data), `robots.txt`, and the
sitemap integration (below). All fit your existing Astro + GitHub Pages setup.

## 1. Copy the files in

- `src/components/SEO.astro` → same path in your project
- `public/robots.txt` → same path in your project (overwrite if one exists)

## 2. Add the sitemap integration

```bash
npx astro add sitemap
```

This installs `@astrojs/sitemap` and should auto-edit `astro.config.mjs`. Confirm it
looks like this (the `site` field is required for sitemap + canonical URLs to work):

```js
// astro.config.mjs
import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

export default defineConfig({
  site: 'https://millkinnisvara.ee',
  integrations: [sitemap()],
});
```

Building the site (`npm run build`) will now output `dist/sitemap-index.xml` and
`dist/sitemap-0.xml` automatically — no extra work needed on each deploy.

## 3. Use the SEO component in your page(s)

In `src/pages/index.astro` (or your layout file), inside `<head>`:

```astro
---
import SEO from '../components/SEO.astro';
---
<html lang="et">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <SEO
      title="Kinnisvara müük ja haldus Tallinnas ja Harjumaal | Mill Kinnisvara"
      description="Mill Kinnisvara aitab kinnisvara kiiresti ja turvaliselt müüa või selle väärtust haldamisega kasvatada. Tasuta hindamine, professionaalne turundus ja kohalik turuteadmine."
      path="/"
    />
  </head>
  ...
```

If/when you split into separate pages (`/muugivahendus`, `/haldus`), give each one
its own `<SEO title=... description=... path="/muugivahendus" />` with page-specific
copy — that's what actually lets each page compete for different search terms.

## 4. Verify the CNAME file survives deploys

Since you're on GitHub Pages with a custom domain, confirm `public/CNAME` contains
just:

```
millkinnisvara.ee
```

GitHub Actions build output needs this file present in `dist/` or the custom domain
setting can get reset on some workflow configs.

## 5. After deploying

- Submit the sitemap URL (`https://millkinnisvara.ee/sitemap-index.xml`) in
  [Google Search Console](https://search.google.com/search-console) and
  [Bing Webmaster Tools](https://www.bing.com/webmasters).
- Set up/verify your **Google Business Profile** with the same name, address, and
  phone number as in the JSON-LD — consistency here matters more for local ranking
  than any on-page tweak.
- Re-run [PageSpeed Insights](https://pagespeed.web.dev/) against the live URL once
  deployed to confirm nothing regressed.
